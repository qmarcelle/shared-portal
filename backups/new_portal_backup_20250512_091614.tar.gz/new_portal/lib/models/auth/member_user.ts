export interface MemberUser {
  id: string;
  name: string;
  dob: string;
  type: string;
}