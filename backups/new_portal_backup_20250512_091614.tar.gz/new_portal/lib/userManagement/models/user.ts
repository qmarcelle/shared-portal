export type MemberUser = {
  id: string;
  name: string;
  dob: string;
  type: 'primary' | 'dependent';
};