export type MemberPlan = {
  id: string;
  name: string;
  subscriber: string;
  policies: string[];
};