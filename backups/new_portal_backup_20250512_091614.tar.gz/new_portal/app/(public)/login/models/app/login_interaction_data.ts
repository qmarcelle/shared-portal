export type LoginInteractionData = {
  interactionId: string;
  interactionToken: string;
};