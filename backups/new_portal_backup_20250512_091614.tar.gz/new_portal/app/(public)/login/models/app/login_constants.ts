export const MIN_CODE_LENGTH = 1;
export const INVALID_CODE_LENGTH = 0;