export interface MfaDeviceMetadata {
  device: string;
  selectionText: string;
}