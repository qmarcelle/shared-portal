export enum MfaModeState {
  selection,
  code,
}