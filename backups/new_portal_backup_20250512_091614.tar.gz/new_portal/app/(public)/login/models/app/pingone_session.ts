export type PingOneSession = {
  interactionId: string;
  interactionToken: string;
  sessionToken: string;
};