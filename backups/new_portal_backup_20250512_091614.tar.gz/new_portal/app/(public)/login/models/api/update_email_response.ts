export interface UpdateEmailResponse {
  interactionId: string;
  interactionToken: string;
  emailId: string;
  message: string;
}