export type AccountDeactivationRequest = {
  primaryUserName: string | undefined;
  umpiId: string | undefined;
  userName: string;
};