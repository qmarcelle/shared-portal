export type AccountDeactivationResponse = {
  status: string;
  message: string;
};