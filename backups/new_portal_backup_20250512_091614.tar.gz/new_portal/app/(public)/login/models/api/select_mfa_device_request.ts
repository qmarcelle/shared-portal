export type SelectMfaDeviceRequest = {
  deviceId: string;
  interactionId: string;
  interactionToken: string;
};