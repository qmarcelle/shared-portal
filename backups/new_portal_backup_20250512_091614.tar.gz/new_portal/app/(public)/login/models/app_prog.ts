export enum AppProg {
  init,
  loading,
  success,
  failed,
}
