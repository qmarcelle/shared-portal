export interface ChatMessage {
  customData?: Record<string, unknown>;
  customFields?: Record<string, unknown>;
  text?: string;
  timestamp?: number;
  type?: 'user' | 'agent' | 'system';
}

export interface ChatState {
  isOpen: boolean;
  isMinimized: boolean;
  messages: ChatMessage[];
  error: string | null;
  isLoading: boolean;
  config: ChatConfig | null;
}

export interface ChatConfig {
  environment: string;
  debug?: boolean;
  isChatAvailable: boolean;
  memberCk: string;
  userRole: string;
  isAmplifyMem: boolean;
  cloudChatEligible: boolean;
  workingHours: boolean;
  chatGroup: string;
}

export type ChatAction =
  | { type: 'OPEN_CHAT' }
  | { type: 'CLOSE_CHAT' }
  | { type: 'MINIMIZE_CHAT' }
  | { type: 'MAXIMIZE_CHAT' }
  | { type: 'ADD_MESSAGE'; message: ChatMessage }
  | { type: 'SET_ERROR'; error: string }
  | { type: 'CLEAR_ERROR' }
  | { type: 'SET_LOADING'; isLoading: boolean }
  | { type: 'SET_CONFIG'; config: ChatConfig }
  | { type: 'RESET_MESSAGES' };
