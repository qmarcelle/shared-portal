/**
 * Chat Types
 * This module contains all the type definitions for the chat functionality
 */

// Chat error types
export type ChatErrorType =
  | 'CONNECTION_ERROR'
  | 'AUTHENTICATION_ERROR'
  | 'CONFIGURATION_ERROR'
  | 'CHAT_START_ERROR'
  | 'CHAT_END_ERROR'
  | 'MESSAGE_ERROR'
  | 'INITIALIZATION_ERROR'
  | 'SCRIPT_LOAD_ERROR'
  | 'API_ERROR'
  | 'ELIGIBILITY_ERROR'
  | 'UNKNOWN_ERROR';

/**
 * ChatError class for standardized error handling
 */
export class ChatError extends Error {
  constructor(
    message: string,
    public type?: ChatErrorType,
  ) {
    super(message);
    this.name = 'ChatError';
  }
}

// Chat configuration types
export interface ChatConfig {
  memberId: string;
  planId: string;
  planName: string;
  hasMultiplePlans: boolean;
  onLockPlanSwitcher: (locked: boolean) => void;
  onOpenPlanSwitcher?: () => void;
}

// Chat state types
export interface ChatState {
  isInitialized: boolean;
  isOpen: boolean;
  isChatActive: boolean;
  isLoading: boolean;
  error: ChatError | null;
  config: ChatConfig;
  currentPlan: PlanInfo | null;
  isPlanSwitcherLocked: boolean;
  session: ChatSession | null;
}

// Chat message types
export interface ChatMessage {
  id: string;
  text: string;
  timestamp: number;
  isFromAgent: boolean;
  agentName?: string;
}

// Chat eligibility types
export interface ChatEligibility {
  chatAvailable: boolean;
  cloudChatEligible: boolean;
  chatGroup?: string;
  workingHours?: string;
  businessHours?: {
    text: string;
    isOpen: boolean;
  };
}

export interface ChatInfoResponse extends ChatEligibility {
  isEligible: boolean;
  businessHours?: {
    text: string;
    isOpen: boolean;
  };
}

// Plan information types
export interface PlanInfo {
  id: string;
  name: string;
  type: string;
  isActive: boolean;
}

// Chat session types
export interface ChatSession {
  id: string;
  startTime: number;
  endTime?: number;
  agentName?: string;
  messages: ChatMessage[];
}

// Chat data payload types
export interface ChatDataPayload {
  // Required fields from ID: 31146
  SERV_Type: string;
  firstname: string;
  RoutingChatbotInteractionId: string;
  PLAN_ID: string;
  lastname: string;
  GROUP_ID: string;
  IDCardBotName: string;
  IsVisionEligible: boolean;
  MEMBER_ID: string;
  coverage_eligibility: string;
  INQ_TYPE: string;
  IsDentalEligible: boolean;
  MEMBER_DOB: string;
  LOB: string;
  lob_group: string;
  IsMedicalEligibile: boolean;
  Origin: string;
  Source: string;

  // Optional fields
  message?: string;
  timestamp?: number;
}

// Chat service interface
export interface ChatService {
  // Properties
  memberId: string;
  planId: string;
  planName: string;
  hasMultiplePlans: boolean;
  onLockPlanSwitcher: (locked: boolean) => void;
  language?: string;
  onError?: (error: Error) => void;
  onAgentJoined?: (agentName: string) => void;
  onAgentLeft?: (agentName: string) => void;
  onChatTransferred?: () => void;
  onTranscriptRequested?: (email: string) => void;
  onFileUploaded?: (file: File) => void;
  enableTranscript?: boolean;
  transcriptPosition?: 'top' | 'bottom';
  transcriptEmail?: string;
  enableFileAttachments?: boolean;
  maxFileSize?: number;
  allowedFileTypes?: string[];

  // Methods
  getChatInfo(): Promise<ChatInfoResponse>;
  startChat(payload: ChatDataPayload): Promise<void>;
  endChat(): Promise<void>;
  sendMessage(text: string): Promise<void>;
  getAuthToken(): Promise<string>;
}

// Hook return interface
export interface UseChatReturn {
  // State
  isInitialized: boolean;
  isOpen: boolean;
  isMinimized: boolean;
  isChatActive: boolean;
  isLoading: boolean;
  error: ChatError | null;
  eligibility: {
    chatAvailable: boolean;
    cloudChatEligible: boolean;
    chatGroup?: string;
    workingHours?: string;
  } | null;

  // Actions
  openChat: () => void;
  closeChat: () => void;
  minimizeChat: () => void;
  maximizeChat: () => void;
  startChat: () => Promise<void>;
  endChat: () => Promise<void>;
  sendMessage: (text: string) => Promise<void>;
}
