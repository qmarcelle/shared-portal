export enum GenesysUserRole {
  MEMBER = 'MEMBER',
  GUEST = 'GUEST',
  ADMIN = 'ADMIN',
}
