export interface GenesysBus {
  runtime: {
    command: (command: string, options?: unknown) => void;
    subscribe: (event: string, callback: (data: unknown) => void) => void;
    unsubscribe?: (event: string) => void;
  };
}

export type GenesysUserRole = 'MEMBER' | 'GUEST' | 'ADMIN';

export interface GenesysWidgets {
  bus: {
    command: (command: string, data?: unknown) => void;
  };
}

export interface ChatMessage {
  customData?: Record<string, unknown>;
  customFields?: Record<string, unknown>;
  content?: string;
  timestamp?: number;
}

export type GenesysCommand =
  | 'Messenger.open'
  | 'Messenger.close'
  | 'Messenger.minimize'
  | 'Messenger.maximize'
  | 'Messenger.start'
  | 'Messenger.end'
  | 'WebChat.open'
  | 'WebChat.close'
  | 'WebChat.minimize'
  | 'WebChat.maximize'
  | 'WebChat.startChat'
  | 'WebChat.endChat';

export type GenesysEvent =
  | 'conversationStarted'
  | 'conversationEnded'
  | 'messageReceived'
  | 'agentJoined'
  | 'agentLeft'
  | 'typingStarted'
  | 'typingEnded'
  | 'ChatStarted'
  | 'ChatEnded'
  | 'MessageReceived'
  | 'AgentJoined'
  | 'AgentLeft'
  | 'TypingStarted'
  | 'TypingEnded';

export type GenesysSDK = {
  (
    action: 'command',
    command: GenesysCommand | string,
    options?: unknown,
  ): void;
  (
    action: 'subscribe',
    event: GenesysEvent | string,
    callback: (data: unknown) => void,
  ): void;
  (action: 'unsubscribe', event: GenesysEvent | string): void;
  (action: 'registerDataSource', data: Record<string, unknown>): void;
  WebMessenger?: {
    destroy: () => void;
    configure: (config: unknown) => void;
  };
  Chat?: {
    destroy: () => void;
    configure: (config: unknown) => void;
  };
  q?: unknown[][];
  t?: number;
  c?: {
    environment: string;
    deploymentId: string;
    [key: string]: unknown;
  };
};

export interface GenesysGlobal {
  (...args: unknown[]): void;
  q?: unknown[];
  c?: {
    pluginsPath: string;
    debug: boolean;
    modules: {
      webchat: {
        transport: {
          deploymentKey: string;
          orgGuid: string;
          markdown: boolean;
          interactionData: {
            routing: {
              targetType: string;
              targetAddress: string;
              priority: number;
            };
          };
        };
        emojis: boolean;
        uploadsEnabled: boolean;
        enableCustomHeader: boolean;
        actionsMenu: boolean;
        maxMessageLength: number;
      };
    };
  };
  t?: number;
  widgets?: GenesysWidgets;
}

// Augment the Window interface
declare global {
  interface Window {
    _genesys?: GenesysGlobal;
    Genesys?: GenesysSDK;
    CXBus?: GenesysBus;
  }
}

export { };

