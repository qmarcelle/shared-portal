import { Member } from '@/models/member/member';
import { SessionUser } from '@/userManagement/models/sessionUser';
import { GenesysConfig } from '../schemas/genesys.schema';

export interface CXBusRuntime {
  command(command: string, options?: unknown): void;
  subscribe(event: string, callback: (data: unknown) => void): void;
  unsubscribe(event: string): void;
}

export type { GenesysConfig };

export interface GenesysTransport {
  deploymentKey?: string;
  orgGuid?: string;
  markdown?: boolean;
  interactionData?: {
    routing?: {
      targetType?: string;
      targetAddress?: string;
      priority?: number;
    };
    attributes?: {
      memberCk?: string;
      networkId?: string;
      userRole?: UserRole;
    };
  };
}

export interface GenesysWidgets {
  main: {
    theme: string;
    lang: string;
    plugins: string[];
    mobileMode: string;
    downloadGoogleFont: boolean;
    containerClass: string;
    themes: {
      light: {
        primary: string;
        primaryFocus: string;
        primaryContent: string;
        secondary: string;
        secondaryFocus: string;
        secondaryContent: string;
        neutral: string;
        base100: string;
        base200: string;
        info: string;
        success: string;
        warning: string;
        error: string;
        fontFamily: string;
      };
    };
    i18n?: {
      en: Record<string, unknown>;
    };
  };
  webchat: {
    transport: GenesysTransport;
    enableCustomHeader: boolean;
    emojis: boolean;
    uploadsEnabled: boolean;
    maxMessageLength: number;
    animationDuration: number;
    autoInvite: {
      enabled: boolean;
      timeToInviteSeconds: number;
      inviteTimeoutSeconds: number;
    };
    chatButton: {
      enabled: boolean;
      openDelay: number;
      effectDuration: number;
      hideDuringInvite: boolean;
      position: string;
      className: string;
    };
    form?: {
      autoFocus: boolean;
      expanded: boolean;
      wrapper: string;
      className: string;
      inputs: Array<{
        id: string;
        name: string;
        type: string;
        options?: string[];
        label?: string;
        required?: boolean;
      }>;
    };
    userData?: {
      memberInfo?: MemberInfo;
    };
  };
  bus: {
    command: (command: string, config?: Record<string, unknown>) => void;
  };
  onReady?: (bus: CXBus) => void;
  initialized?: boolean;
}

export interface CXBus {
  runtime: {
    subscribe: (event: string, callback: (error: unknown) => void) => void;
    command: (command: string, config?: unknown) => void;
  };
  command: (command: string, config?: unknown) => void;
}

export interface WebConfig {
  chatbotEligible: boolean | string;
  routingchatbotEligible: boolean | string;
  clientId: string;
  chatUrl: string;
  environment: string;
  debug: boolean;
  isChatAvailable: boolean | string;
  memberCk: string;
  userRole: string;
  isAmplifyMem: boolean;
  isDemoMember?: boolean;
  workingHrs?: string;
  rawChatHrs?: string;
  clickToChatEndPoint?: string;
  clickToChatDemoEndPoint?: string;
  calculatedCiciId?: string;
}

export interface MemberInfo
  extends Partial<
    Pick<Member, 'firstName' | 'lastName' | 'groupId' | 'subscriberId'>
  > {
  memberCk?: string;
  subscriberCk?: string;
  networkId?: string;
  planFhirId?: string;
  umpi?: string;
  userFhirId?: string;
  email?: string;
  phone?: string;
  userRole?: UserRole;
  isDental?: 'Y' | 'N';
  isMedical?: 'Y' | 'N';
  isVision?: 'Y' | 'N';
  groupType?: string;
  dob?: string;
  sfx?: string;
}

export interface ChatMessageEvent {
  data?: {
    message?: {
      type?: string;
    };
  };
}

export interface ChatPlugin {
  command: (command: string, data?: Record<string, unknown>) => Promise<void>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  subscribe: (event: string, callback: (...args: any[]) => void) => void;
}

export type UserRole = 'MEMBER' | 'PERSONAL_REPRESENTATIVE' | 'GUEST';

export type ChatOption = {
  text: string;
  value?: string;
  disabled?: string;
  selected?: string;
};

export interface FormInput {
  custom: string;
}

export interface ChatForm {
  inputs: FormInput[];
}

export interface AfterHoursLink {
  key: string;
  value: string;
}

export interface MemberEligibility {
  isDental: string;
  isMedical: string;
  isVision: string;
  isWellnessOnly: string;
  isCobraEligible: string;
  isIDCardEligible: string;
  chatbotEligible: string;
  groupType: string;
}

export interface ClientIdentification {
  isBlueEliteGroup: boolean | string;
  groupType: string;
  memberClientId: string;
  calculatedCiciId: string;
}

export interface ChatConfig extends WebConfig {
  isDemoMember: boolean;
  isDental: boolean;
  isMedical: boolean;
  isVision: boolean;
  isWellnessOnly: boolean;
  isCobraEligible: boolean;
  groupType: string;
  isIDCardEligible: boolean | string;
  calculatedCiciId: string;
  rawChatHrs: string;
  clickToChatEndPoint?: string;
  clickToChatDemoEndPoint?: string;
}

// --- Chat Store Types (moved from store/chatStore.ts) ---
export type AgentParticipant = {
  id: string;
  name: string;
  // add more fields as needed
};

export type GuestConversationRsp = {
  chat: {
    chatId: string;
    sessionId: string;
    secureKey: string;
    jwt: string;
    alias: string;
    mediaType: string;
    state: 'idle' | 'queued' | 'connected' | 'ended';
    welcomeMessage: string;
  };
  endPoints: {
    events: string;
    messages: string;
    uploads: string;
  };
  queueName: string;
  estimatedWait: number;
  agentTypingTimeout?: number;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any;
};

export type ChatEvent =
  | { type: 'queue-position'; position: number }
  | { type: 'connected'; participants?: AgentParticipant[] }
  | { type: 'message'; message: ChatMessage }
  | { type: 'agent-typing'; value: boolean }
  | { type: 'ended' }
  | { type: 'error'; reason: string };

export type ChatMessage = {
  id?: string;
  text?: string;
  sender?: string;
  timestamp?: string;
  // add more fields as needed
};

export interface SessionData {
  chatConfig: ChatConfig;
  isAmplifyMem: boolean;
  isBlueEliteGroup: boolean;
  memberCk: string;
  memberInfo: MemberInfo;
}

export interface GenesysComponentProps {
  sessionData: SessionData;
}

export interface ChatState {
  // State
  memberInfo: {
    memberCk: string;
    firstName: string;
    lastName: string;
    groupId: string;
    userRole: 'GUEST';
    isDental: 'N';
    isMedical: 'N';
    isVision: 'N';
    dob: string;
    subscriberId: string;
    sfx: string;
  };
  config: WebConfig;
  webConfig: WebConfig;
  isReloading: boolean;
  globalsReady: boolean;
  uiState: {
    isMinimized: boolean;
    isOpen: boolean;
    newMessageCount: number;
    isPlanSwitcherLocked: boolean;
    planSwitcherTooltip: string;
    eligibility: {
      isEligible: boolean;
      hasMultiplePlans: boolean;
      isOpen: boolean;
      hoursText: string;
    };
  };
  // Runtime chat state
  chatId?: string;
  state?: 'idle' | 'queued' | 'connected' | 'ended';
  queuePos?: number;
  participants: AgentParticipant[];
  messages: ChatMessage[];
  isTyping: boolean;
  error?: string;
  plugin: { localWidgetPlugin: ChatPlugin | null; webAlert: WebAlert | null };

  // Actions
  setUIState: (state: Partial<ChatState['uiState']>) => void;
  toggleMinimized: () => void;
  incrementUnreadCount: () => void;
  resetUnreadCount: () => void;
  togglePlanSwitcherLock: (locked: boolean) => void;
  updateEligibility: (
    eligibility: Partial<ChatState['uiState']['eligibility']>,
  ) => void;
  setMemberInfo: (info: Partial<MemberInfo>) => void;
  setConfig: (cfg: Partial<WebConfig>) => void;
  setWebConfig: (cfg: Partial<WebConfig>) => void;
  initializeWebConfig: () => void;
  updateCalculatedCiciId: () => void;
  setPlugin: (p: Partial<ChatState['plugin']>) => void;
  setIsReloading: (val: boolean) => void;
  setGlobalsReady: (val: boolean) => void;
  syncWithSessionUser: (session: SessionUser) => void;
  hydrate: (rsp: GuestConversationRsp) => void;
  ingestEvent: (ev: ChatEvent) => void;
  resetRuntime: () => void;
}

export interface WebAlert {
  play: () => Promise<void>;
  muted: boolean;
}

export interface GenesysBus {
  command(command: string, ...args: unknown[]): Promise<unknown>;
  subscribe(event: string, handler: (...args: unknown[]) => void): void;
  runtime: CXBusRuntime;
}

export interface GenesysGlobal {
  (...args: unknown[]): void;
  q?: unknown[];
  t?: number;
  c?: Record<string, unknown>;
  onReady?: ((bus: CXBus) => void)[];
  widgets?: {
    register?: (name: string, widget: unknown) => void;
    registerPlugin?: (name: string, plugin: unknown) => void;
    bus?: GenesysBus;
  };
}
