import type { ChatInfoResponse } from '@/utils/api/memberService';

export type { ChatInfoResponse };
